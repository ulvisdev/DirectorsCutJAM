#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "GameFramework/GameModeBase.h"
#include "GameFramework/HUD.h"
#include "CutTo.generated.h"

class UBoxComponent;
class USceneComponent;
class USpringArmComponent;
class UCameraComponent;

/** Shot axes are momentum frames; spawn is independently configurable and kept upright. */
UCLASS(Blueprintable)
class DIRECTORSCUTJAM_API ACutShot : public AActor
{
    GENERATED_BODY()
public:
    ACutShot();
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly) TObjectPtr<UBoxComponent> ShotArea;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly) TObjectPtr<USceneComponent> MomentumFrame;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly) TObjectPtr<USceneComponent> Arrival;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="CUT") TObjectPtr<ACutShot> Destination;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="CUT") FString ShotName = TEXT("01 A");
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="CUT") bool bEnabled = true;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="CUT") int32 Challenge = 1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="CUT") bool bRequireFalling = false;
    bool Contains(const FVector& Point) const;
    FQuat RotationToDestination() const;
};

UCLASS()
class DIRECTORSCUTJAM_API ACutPerformer : public ACharacter
{
    GENERATED_BODY()
public:
    ACutPerformer();
    virtual void BeginPlay() override;
    virtual void Tick(float DeltaSeconds) override;
    virtual void SetupPlayerInputComponent(UInputComponent* Input) override;
    UPROPERTY(VisibleAnywhere) TObjectPtr<USpringArmComponent> Boom;
    UPROPERTY(VisibleAnywhere) TObjectPtr<UCameraComponent> Camera;
    UPROPERTY(EditAnywhere, Category="Movement") float RunSpeed = 640.f;
    UPROPERTY(EditAnywhere, Category="Movement") float SprintSpeed = 940.f;
    UPROPERTY(EditAnywhere, Category="CUT") float CutCooldown = .3f;
    UPROPERTY(BlueprintReadOnly) int32 CurrentChallenge = 1;
    UPROPERTY(BlueprintReadOnly) bool bFinished = false;
    UPROPERTY(BlueprintReadOnly) FString Feedback;
    float Flash = 0.f;
    float LastCutSpeed = 0.f;
    int32 CutCount = 0;
    FVector Checkpoint = FVector(-1100,0,180);
    FRotator CheckpointFacing = FRotator::ZeroRotator;
    ACutShot* AvailableShot() const;
    UFUNCTION(BlueprintCallable) bool Cut();
    UFUNCTION(BlueprintCallable) void Restart();
    void SetCheckpoint(int32 Number, FVector Position);
private:
    void Forward(float Value);
    void Right(float Value);
    void LookX(float Value);
    void LookY(float Value);
    void SprintOn();
    void SprintOff();
    float Cooldown = 0;
    float CarryTime = 0;
    float CoyoteTime = 0;
    float JumpBuffer = 0;
    bool bSprinting = false;
    void PressJump();
    void PressCut() { Cut(); }
    TArray<TWeakObjectPtr<ACutShot>> Shots;
};

UCLASS()
class DIRECTORSCUTJAM_API ACutHUD : public AHUD
{
    GENERATED_BODY()
public:
    virtual void DrawHUD() override;
};

/** Generates editor-owned geometry; rebuilding only removes actors tagged CutToGenerated. */
UCLASS(Blueprintable)
class DIRECTORSCUTJAM_API ACutStudio : public AActor
{
    GENERATED_BODY()
public:
    ACutStudio();
    UFUNCTION(CallInEditor, BlueprintCallable, Category="CUT TO") void BuildStudio();
};

UCLASS()
class DIRECTORSCUTJAM_API ACutGameMode : public AGameModeBase
{
    GENERATED_BODY()
public:
    ACutGameMode();
    virtual void BeginPlay() override;
    virtual void Tick(float DeltaSeconds) override;
private:
    bool bSmoke = false;
    int32 SmokeStep = 0;
    float SmokeTime = 0;
    float LaunchX = 0;
    void SmokeCheck(bool Result, const TCHAR* Message);
    int32 Failures = 0;
};
