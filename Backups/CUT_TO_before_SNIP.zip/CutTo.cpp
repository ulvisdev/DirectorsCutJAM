#include "CutTo.h"
#include "Modules/ModuleManager.h"
#include "Camera/CameraComponent.h"
#include "Components/BoxComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/TextRenderComponent.h"
#include "Components/ArrowComponent.h"
#include "Components/DirectionalLightComponent.h"
#include "Components/PointLightComponent.h"
#include "Components/SkyLightComponent.h"
#include "Engine/DirectionalLight.h"
#include "Engine/PointLight.h"
#include "Engine/SkyLight.h"
#include "Engine/StaticMeshActor.h"
#include "Engine/Canvas.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/PlayerStart.h"
#include "GameFramework/WorldSettings.h"
#include "Kismet/GameplayStatics.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Misc/CommandLine.h"
#include "Misc/Parse.h"
#include "HAL/PlatformMisc.h"
#include "Animation/AnimInstance.h"
#include "DrawDebugHelpers.h"
#include "UnrealClient.h"

IMPLEMENT_PRIMARY_GAME_MODULE(FDefaultGameModuleImpl, DirectorsCutJAM, "DirectorsCutJAM");
DEFINE_LOG_CATEGORY_STATIC(LogCutTo, Log, All);

ACutShot::ACutShot()
{
    RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("ShotRoot"));
    ShotArea = CreateDefaultSubobject<UBoxComponent>(TEXT("ActivationArea"));
    ShotArea->SetupAttachment(RootComponent);
    ShotArea->SetBoxExtent(FVector(300,400,300));
    ShotArea->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    ShotArea->SetHiddenInGame(true);
    MomentumFrame = CreateDefaultSubobject<USceneComponent>(TEXT("MomentumFrame"));
    MomentumFrame->SetupAttachment(RootComponent);
    Arrival = CreateDefaultSubobject<USceneComponent>(TEXT("SafeArrival"));
    Arrival->SetupAttachment(RootComponent);
    auto* Arrow = CreateDefaultSubobject<UArrowComponent>(TEXT("MomentumDirection"));
    Arrow->SetupAttachment(MomentumFrame);
    Arrow->ArrowColor = FColor::Cyan;
    Arrow->ArrowSize = 3;
    auto* SpawnArrow = CreateDefaultSubobject<UArrowComponent>(TEXT("ArrivalDirection"));
    SpawnArrow->SetupAttachment(Arrival);
    SpawnArrow->ArrowColor = FColor::Green;
}
bool ACutShot::Contains(const FVector& Point) const
{
    const FVector E=ShotArea->GetUnscaledBoxExtent();
    const FVector P=ShotArea->GetComponentTransform().InverseTransformPosition(Point).GetAbs();
    return bEnabled && P.X<=E.X && P.Y<=E.Y && P.Z<=E.Z;
}
FQuat ACutShot::RotationToDestination() const
{
    return Destination ? (Destination->MomentumFrame->GetComponentQuat() * MomentumFrame->GetComponentQuat().Inverse()).GetNormalized() : FQuat::Identity;
}

ACutPerformer::ACutPerformer()
{
    PrimaryActorTick.bCanEverTick = true;
    GetCapsuleComponent()->InitCapsuleSize(34,88);
    bUseControllerRotationYaw = false;
    auto* M = GetCharacterMovement();
    M->bOrientRotationToMovement = true;
    M->RotationRate = FRotator(0,700,0);
    M->MaxWalkSpeed = RunSpeed;
    M->MaxAcceleration = 4200;
    M->BrakingDecelerationWalking = 3000;
    M->JumpZVelocity = 650;
    M->GravityScale = 1.45f;
    M->AirControl = .65f;
    M->FallingLateralFriction = 0;
    M->BrakingDecelerationFalling = 0;
    M->MaxSimulationTimeStep = .016f;
    // Keep the small physics steps even during editor background throttling or hitches.
    M->MaxSimulationIterations = 32;
    Boom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
    Boom->SetupAttachment(RootComponent);
    Boom->TargetArmLength = 430;
    Boom->SocketOffset = FVector(0,55,70);
    Boom->bUsePawnControlRotation = true;
    Boom->bEnableCameraLag = true;
    Boom->CameraLagSpeed = 16;
    Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
    Camera->SetupAttachment(Boom);
    Camera->FieldOfView = 88;
    if (auto* MeshAsset = LoadObject<USkeletalMesh>(nullptr,TEXT("/Game/Characters/Mannequins/Meshes/SKM_Manny_Simple.SKM_Manny_Simple")))
    {
        GetMesh()->SetSkeletalMesh(MeshAsset);
        GetMesh()->SetRelativeLocation(FVector(0,0,-88));
        GetMesh()->SetRelativeRotation(FRotator(0,-90,0));
        if (auto* Anim = LoadClass<UAnimInstance>(nullptr,TEXT("/Game/Characters/Mannequins/Anims/Unarmed/ABP_Unarmed.ABP_Unarmed_C"))) GetMesh()->SetAnimInstanceClass(Anim);
    }
}
void ACutPerformer::BeginPlay()
{
    Super::BeginPlay();
    for (TActorIterator<ACutShot> It(GetWorld()); It; ++It) Shots.Add(*It);
    if (auto* PC = Cast<APlayerController>(Controller))
    {
        PC->SetControlRotation(FRotator(-12,0,0));
        PC->SetInputMode(FInputModeGameOnly());
        PC->bShowMouseCursor = false;
    }
}
void ACutPerformer::SetupPlayerInputComponent(UInputComponent* Input)
{
    Super::SetupPlayerInputComponent(Input);
    Input->BindAxis("CutForward",this,&ACutPerformer::Forward);
    Input->BindAxis("CutRight",this,&ACutPerformer::Right);
    Input->BindAxis("CutLookX",this,&ACutPerformer::LookX);
    Input->BindAxis("CutLookY",this,&ACutPerformer::LookY);
    Input->BindAction("CutJump",IE_Pressed,this,&ACutPerformer::PressJump);
    Input->BindAction("CutJump",IE_Released,this,&ACharacter::StopJumping);
    Input->BindAction("CutSprint",IE_Pressed,this,&ACutPerformer::SprintOn);
    Input->BindAction("CutSprint",IE_Released,this,&ACutPerformer::SprintOff);
    Input->BindAction("CutEdit",IE_Pressed,this,&ACutPerformer::PressCut);
    Input->BindAction("CutRestart",IE_Pressed,this,&ACutPerformer::Restart);
}
void ACutPerformer::Forward(float V) { if(Controller && !bFinished) AddMovementInput(FRotator(0,Controller->GetControlRotation().Yaw,0).Vector(),V); }
void ACutPerformer::Right(float V) { if(Controller && !bFinished) AddMovementInput(FRotationMatrix(FRotator(0,Controller->GetControlRotation().Yaw,0)).GetUnitAxis(EAxis::Y),V); }
void ACutPerformer::LookX(float V) { AddControllerYawInput(V); }
void ACutPerformer::LookY(float V) { AddControllerPitchInput(V); }
void ACutPerformer::SprintOn() { bSprinting=true; }
void ACutPerformer::SprintOff() { bSprinting=false; }
void ACutPerformer::PressJump()
{
    if (bFinished) return;
    JumpBuffer=.12f;
    if (GetCharacterMovement()->IsMovingOnGround()) Jump();
    else if (CoyoteTime>0) { LaunchCharacter(FVector(0,0,650),false,true); CoyoteTime=0; JumpBuffer=0; }
}
ACutShot* ACutPerformer::AvailableShot() const
{
    if (bFinished || Cooldown>0) return nullptr;
    ACutShot* Best=nullptr;
    float Distance=MAX_flt;
    for (const auto& Weak : Shots)
        if (ACutShot* S=Weak.Get(); S && S->Destination && S->Challenge==CurrentChallenge && S->Contains(GetActorLocation()) && (!S->bRequireFalling || GetVelocity().Z < -350))
        {
            const float D=FVector::DistSquared(S->GetActorLocation(),GetActorLocation());
            if (D<Distance) { Best=S; Distance=D; }
        }
    return Best;
}
bool ACutPerformer::Cut()
{
    ACutShot* S=AvailableShot();
    if (!S) { Feedback=TEXT("Find the illuminated shot frame. Falling shots need downward speed."); return false; }
    const FQuat Delta=S->RotationToDestination();
    const FVector OldVelocity=GetCharacterMovement()->Velocity;
    const FVector NewVelocity=Delta.RotateVector(OldVelocity);
    const FVector Target=S->Destination->Arrival->GetComponentLocation();
    // Never adjust into nearby geometry: reject blocked destinations, leaving the performer untouched.
    FCollisionQueryParams Query(SCENE_QUERY_STAT(CutArrival),false,this);
    if (GetWorld()->OverlapBlockingTestByChannel(Target,FQuat::Identity,ECC_Pawn,
        FCollisionShape::MakeCapsule(GetCapsuleComponent()->GetScaledCapsuleRadius(),GetCapsuleComponent()->GetScaledCapsuleHalfHeight()),Query))
    { Feedback=TEXT("Destination blocked. Reset the take with R."); return false; }
    FVector Facing=Delta.RotateVector(GetActorForwardVector());
    if (Facing.SizeSquared2D()<.01f) Facing=S->Destination->Arrival->GetForwardVector();
    const FRotator Upright(0,Facing.Rotation().Yaw,0);
    if (!TeleportTo(Target,Upright,false,true)) return false;
    if (Controller)
    {
        // Keep the viewing horizon level; pitch belongs to momentum, not the player's neck.
        FVector View=Delta.RotateVector(FRotator(0,Controller->GetControlRotation().Yaw,0).Vector());
        const float Yaw=View.SizeSquared2D()>.01f ? View.Rotation().Yaw : S->Destination->Arrival->GetComponentRotation().Yaw;
        Controller->SetControlRotation(FRotator(-12,Yaw,0));
    }
    auto* M=GetCharacterMovement();
    M->SetMovementMode(MOVE_Falling);
    M->Velocity=NewVelocity;
    M->UpdateComponentVelocity();
    // Lift the air speed cap for the launch; CharacterMovement otherwise brakes high-speed cuts.
    CarryTime=2.5f;
    M->MaxWalkSpeed=FMath::Max(SprintSpeed,NewVelocity.Size2D());
    Boom->bEnableCameraLag=false;
    Cooldown=CutCooldown;
    Flash=.16f;
    LastCutSpeed=NewVelocity.Size();
    ++CutCount;
    Feedback=FString::Printf(TEXT("%s  >  %s   |   %.0f cm/s carried"),*S->ShotName,*S->Destination->ShotName,LastCutSpeed);
    UE_LOG(LogCutTo,Display,TEXT("CUT %s -> %s speed %.3f -> %.3f velocity %s"),*S->ShotName,*S->Destination->ShotName,OldVelocity.Size(),NewVelocity.Size(),*NewVelocity.ToString());
    return true;
}
void ACutPerformer::SetCheckpoint(int32 Number,FVector Position)
{
    if (Number<=CurrentChallenge) return;
    CurrentChallenge=Number;
    Checkpoint=Position;
    Feedback=TEXT("CHECKPOINT  |  New scene ready. R restarts this scene.");
}
void ACutPerformer::Restart()
{
    bFinished=false;
    TeleportTo(Checkpoint,CheckpointFacing,false,true);
    GetCharacterMovement()->StopMovementImmediately();
    GetCharacterMovement()->SetMovementMode(MOVE_Falling);
    if(Controller) Controller->SetControlRotation(FRotator(-12,CheckpointFacing.Yaw,0));
    Cooldown=0; CarryTime=0; Flash=.12f;
    Feedback=TEXT("BACK TO ONE!  |  Take it again.");
}
void ACutPerformer::Tick(float Dt)
{
    Super::Tick(Dt);
    Cooldown=FMath::Max(0.f,Cooldown-Dt);
    Flash=FMath::Max(0.f,Flash-Dt);
    Boom->bEnableCameraLag=Flash<=0;
    CarryTime=FMath::Max(0.f,CarryTime-Dt);
    auto* M=GetCharacterMovement();
    if(M->IsMovingOnGround()) { CarryTime=0; CoyoteTime=.1f; if(JumpBuffer>0) Jump(); }
    else CoyoteTime=FMath::Max(0.f,CoyoteTime-Dt);
    JumpBuffer=FMath::Max(0.f,JumpBuffer-Dt);
    if(CarryTime<=0 || M->IsMovingOnGround()) M->MaxWalkSpeed=bSprinting?SprintSpeed:RunSpeed;
    const FVector P=GetActorLocation();
    // Checkpoints only arm on their safe landing platforms, never in flight over the gaps.
    if(M->IsMovingOnGround() && P.X>3750 && P.X<4650 && P.Z>1650 && FMath::Abs(P.Y)<650) SetCheckpoint(2,FVector(4200,0,1860));
    if(M->IsMovingOnGround() && P.X>7900 && P.X<10100 && FMath::Abs(P.Y)<950) SetCheckpoint(3,FVector(8500,0,180));
    if(CurrentChallenge==3 && M->IsMovingOnGround() && P.X>15000 && P.X<17100 && FMath::Abs(P.Y)<1000 && !bFinished)
    { bFinished=true; Feedback=TEXT("THAT'S A WRAP!  |  R to replay the final stunt."); }
    if(P.Z < -2000 || P.Y>5000 || P.Y< -5000) Restart();
}

void ACutHUD::DrawHUD()
{
    Super::DrawHUD();
    auto* P=Cast<ACutPerformer>(GetOwningPawn());
    if(!P || !Canvas) return;
    const float W=Canvas->SizeX,H=Canvas->SizeY;
    const float Scale=FMath::Clamp(W/1600.f,.7f,1.3f);
    auto Text=[&](const FString& S,float X,float Y,FLinearColor C,float Size=1.f)
    { DrawText(S,C,X,Y,GEngine->GetLargeFont(),Size*Scale*2.f); };
    DrawRect(FLinearColor(.008f,.012f,.022f,.9f),0,0,W,100*Scale);
    Text(TEXT("CUT TO!"),32,18,FLinearColor(1,.72f,.28f),1.6f);
    const TCHAR* Names[]={TEXT(""),TEXT("01 / THE MISSING BRIDGE"),TEXT("02 / THE FALLING SHOT"),TEXT("03 / THE FINAL STUNT")};
    Text(Names[P->CurrentChallenge],250*Scale,26,FLinearColor::White,.95f);
    Text(TEXT("WASD move   /   MOUSE look   /   SPACE jump   /   SHIFT sprint   /   E cut   /   R restart"),32,H-48*Scale,FLinearColor(.85f,.86f,.9f),.75f);
    DrawRect(FLinearColor(.008f,.012f,.022f,.85f),0,H-165*Scale,W,100*Scale);
    ACutShot* Shot=P->AvailableShot();
    Text(Shot?FString::Printf(TEXT("[ E ]  CUT READY    %s  >  %s"),*Shot->ShotName,*Shot->Destination->ShotName):TEXT("CUT STANDBY  /  Enter a glowing shot frame"),32,H-150*Scale,Shot?FLinearColor(.25f,1,.8f):FLinearColor(.65f,.68f,.75f),.95f);
    const TCHAR* Tips[]={TEXT(""),TEXT("Run + jump into the cyan frame. Press E in the air to cross the missing bridge."),TEXT("Step off the tower. Fall into the gold frame, then E: DOWN becomes FORWARD."),TEXT("Cut across the bridge, drop into the pink frame, then launch toward the WRAP stage.")};
    Text(Tips[P->CurrentChallenge],32,112*Scale,FLinearColor(1,.86f,.6f),.8f);
    Text(P->Feedback,32,H-105*Scale,FLinearColor(.8f,.83f,.9f),.65f);
    Text(FString::Printf(TEXT("SPEED  %04.0f cm/s     CUTS  %02d"),P->GetVelocity().Size(),P->CutCount),W-400*Scale,65*Scale,FLinearColor(.4f,.9f,.85f),.7f);
    if(P->Flash>0)
    {
        DrawRect(FLinearColor(.02f,.025f,.04f,.94f*P->Flash/.16f),0,H*.43f,W,H*.14f);
        Text(TEXT("CUT!"),W*.45f,H*.46f,FLinearColor(1,.85f,.5f),2.4f);
    }
    if(P->bFinished)
    {
        DrawRect(FLinearColor(.01f,.02f,.035f,.92f),W*.15f,H*.32f,W*.7f,H*.3f);
        Text(TEXT("THAT'S A WRAP!"),W*.28f,H*.4f,FLinearColor(1,.75f,.3f),2.2f);
        Text(TEXT("ONE BUTTON. TWO SHOTS. MOMENTUM NEVER STOPS."),W*.24f,H*.53f,FLinearColor::White,.8f);
    }
}

ACutStudio::ACutStudio() { RootComponent=CreateDefaultSubobject<USceneComponent>(TEXT("StudioRoot")); }

void ACutStudio::BuildStudio()
{
    UWorld* World=GetWorld();
    if(!World) return;
    TArray<AActor*> Old;
    for(TActorIterator<AActor> It(World);It;++It) if(It->ActorHasTag(TEXT("CutToGenerated"))) Old.Add(*It);
    for(AActor* A:Old) World->DestroyActor(A);
    auto Tag=[](AActor* A,const FString& Name)
    {
        A->Tags.AddUnique(TEXT("CutToGenerated"));
#if WITH_EDITOR
        A->SetActorLabel(Name);
        A->SetFolderPath(TEXT("CUT TO / Generated"));
#endif
    };
    auto Box=[&](FString Name,FVector Pos,FVector Size,FLinearColor Color,bool Collision=true,FRotator Rotation=FRotator::ZeroRotator,const TCHAR* Shape=TEXT("Cube"))->AStaticMeshActor*
    {
        auto* A=World->SpawnActor<AStaticMeshActor>(Pos,Rotation);
        Tag(A,Name);
        auto* C=A->GetStaticMeshComponent();
        C->SetMobility(EComponentMobility::Movable);
        C->SetStaticMesh(LoadObject<UStaticMesh>(nullptr,*FString::Printf(TEXT("/Engine/BasicShapes/%s.%s"),Shape,Shape)));
        A->SetActorScale3D(Size/100.f);
        C->SetCollisionEnabled(Collision?ECollisionEnabled::QueryAndPhysics:ECollisionEnabled::NoCollision);
        const FString MatName=FString::Printf(TEXT("MI_R%d_G%d_B%d"),FMath::RoundToInt(Color.R*1000),FMath::RoundToInt(Color.G*1000),FMath::RoundToInt(Color.B*1000));
        if(auto* Mat=LoadObject<UMaterialInterface>(nullptr,*(TEXT("/Game/CutTo/Materials/")+MatName+TEXT(".")+MatName))) C->SetMaterial(0,Mat);
        return A;
    };
    auto Label=[&](FString Value,FVector Pos,float Size,FColor Color=FColor(255,220,160),FRotator Rot=FRotator(0,180,0))
    {
        auto* A=World->SpawnActor<AActor>(Pos,Rot); Tag(A,TEXT("SIGN / ")+Value);
        auto* T=NewObject<UTextRenderComponent>(A); A->AddInstanceComponent(T); A->SetRootComponent(T);
        T->RegisterComponent(); A->SetActorLocationAndRotation(Pos,Rot);
        T->SetText(FText::FromString(Value)); T->SetWorldSize(Size); T->SetTextRenderColor(Color);
        T->SetHorizontalAlignment(EHTA_Center); T->SetVerticalAlignment(EVRTA_TextCenter);
    };
    const FLinearColor Wood(.24f,.12f,.055f),Dark(.028f,.042f,.065f),Gold(1,.55f,.10f),Cyan(.05f,.7f,.8f),Pink(.85f,.12f,.36f),Cream(.8f,.73f,.52f);
    auto Platform=[&](FString Name,FVector Center,FVector Size,FLinearColor Accent)
    {
        Box(Name,Center-FVector(0,0,50),FVector(Size.X,Size.Y,100),Wood);
        Box(Name+TEXT(" / apron"),Center-FVector(0,0,120),FVector(Size.X,Size.Y,45),Dark);
        for(float Y : {-Size.Y*.5f,Size.Y*.5f})
        {
            Box(TEXT("Illuminated stage edge"),Center+FVector(0,Y,4),FVector(Size.X,14,8),Accent,false);
            for(float X : {-Size.X*.4f,Size.X*.4f}) Box(TEXT("Scaffold upright"),Center+FVector(X,Y,-500),FVector(24,24,1000),Dark);
        }
        for(float X=-Size.X*.5f+100;X<Size.X*.5f;X+=150) Box(TEXT("Deck seam"),Center+FVector(X,0,1),FVector(3,Size.Y,2),Cream,false);
    };
    auto CameraProp=[&](FVector P,FLinearColor Color)
    {
        Box(TEXT("Vintage camera body"),P+FVector(0,0,150),FVector(100,65,65),Dark,false);
        Box(TEXT("Lens"),P+FVector(65,0,150),FVector(45,40,40),Color,false,FRotator(90,0,0),TEXT("Cylinder"));
        for(float X : {-25.f,25.f}) Box(TEXT("Film reel"),P+FVector(X,0,205),FVector(65,20,65),Dark,false,FRotator(90,0,0),TEXT("Cylinder"));
        for(float Y : {-30.f,30.f}) Box(TEXT("Tripod"),P+FVector(0,Y,65),FVector(12,12,150),Cream,false,FRotator(0,0,Y>0?16:-16));
        Box(TEXT("Tripod third leg"),P+FVector(-30,0,65),FVector(12,12,150),Cream,false,FRotator(-16,0,0));
    };
    auto Shot=[&](FString Name,FVector P,FVector Extent,FRotator Frame,int32 Challenge,FLinearColor Color,bool Falling=false)->ACutShot*
    {
        auto* S=World->SpawnActor<ACutShot>(P,FRotator::ZeroRotator); Tag(S,TEXT("SHOT / ")+Name);
        S->ShotName=Name; S->Challenge=Challenge; S->bRequireFalling=Falling;
        S->ShotArea->SetBoxExtent(Extent); S->MomentumFrame->SetRelativeRotation(Frame);
        // Frames are readable without obscuring either the third-person camera or the landing.
        for(float Y:{-Extent.Y,Extent.Y}) Box(TEXT("Shot frame post"),P+FVector(0,Y,0),FVector(16,16,Extent.Z*2),Color,false);
        for(float Z:{-Extent.Z,Extent.Z}) Box(TEXT("Shot frame lintel"),P+FVector(0,0,Z),FVector(16,Extent.Y*2,16),Color,false);
        CameraProp(P+FVector(-100,Extent.Y+140,-Extent.Z),Color);
        Label(Name,P+FVector(-15,0,Extent.Z+100),65,Color.ToFColor(true));
        return S;
    };
    auto Arrow=[&](FVector P,FLinearColor Color)
    {
        Box(TEXT("Launch direction shaft"),P,FVector(220,22,12),Color,false);
        Box(TEXT("Launch direction head"),P+FVector(90,35,0),FVector(90,18,12),Color,false,FRotator(0,-40,0));
        Box(TEXT("Launch direction head"),P+FVector(90,-35,0),FVector(90,18,12),Color,false,FRotator(0,40,0));
    };
    // Scene 1: a gap wider than a sprint jump. Arrival is over the second deck.
    Platform(TEXT("01 / rehearsal runway"),FVector(-500,0,0),FVector(2000,1200,0),Cyan);
    Platform(TEXT("01 / bridge landing"),FVector(2550,0,0),FVector(1700,1400,0),Cyan);
    auto* A=Shot(TEXT("01 A"),FVector(400,0,220),FVector(320,450,300),FRotator::ZeroRotator,1,Cyan);
    auto* B=Shot(TEXT("01 B"),FVector(1850,0,250),FVector(120,450,160),FRotator::ZeroRotator,1,Cyan);
    B->Arrival->SetRelativeLocation(FVector(100,0,0)); A->Destination=B; B->Destination=A;
    A->Arrival->SetRelativeLocation(FVector(-200,0,0));
    Arrow(FVector(2200,0,8),Cyan);
    Label(TEXT("CUT TO!\nONE BUTTON. TWO SHOTS.\nMOMENTUM NEVER STOPS."),FVector(-300,-800,330),45,FColor(255,220,160),FRotator(0,145,0));
    Label(TEXT("01 / THE MISSING BRIDGE\nSPRINT + JUMP + E"),FVector(450,0,630),45,FColor::Cyan);
    Label(TEXT("NEXT SCENE  >  GOLD STAIRS"),FVector(3050,0,330),45);
    // Walkable staircase takes the performer to the tower and safely arms scene 2.
    for(int32 I=0;I<48;++I)
        Box(TEXT("Tower staircase"),FVector(1900+I*38,0,(I+1)*35-17.5f),FVector(76,650,35),I%2?Wood:Dark,false);
    // Smooth collision avoids repeated step-up velocity loss on the scenic stairs.
    auto* StairRamp=Box(TEXT("Staircase smooth collision"),FVector(2793,0,840),FVector(2530,650,35),Wood,true,FRotator(42.65f,0,0));
    StairRamp->SetActorHiddenInGame(true);
    Platform(TEXT("02 / tower deck"),FVector(4200,0,1680),FVector(900,1300,0),Gold);
    Label(TEXT("02 / THE FALLING SHOT\nSTEP OFF. FALL. CUT IN GOLD."),FVector(4480,0,2350),65,FColor(255,190,60));
    // -Z source velocity rotated +90 degrees about pitch becomes +X.
    auto* C=Shot(TEXT("02 A / DOWN"),FVector(4900,0,500),FVector(900,600,650),FRotator::ZeroRotator,2,Gold,true);
    auto* D=Shot(TEXT("02 B / FORWARD"),FVector(6100,0,1000),FVector(100,500,220),FRotator(90,0,0),2,Gold);
    C->Destination=D; D->Destination=C;
    D->Arrival->SetRelativeLocation(FVector(0,0,0));
    Platform(TEXT("02 / broad stunt landing"),FVector(8350,0,0),FVector(2300,2000,0),Gold);
    Arrow(FVector(7600,0,8),Gold);
    Label(TEXT("DOWN  >  FORWARD\nKEEP YOUR SPEED"),FVector(7350,0,850),80,FColor(255,190,60));
    // Scene 3: running cut to raised deck, then falling cut to the finale.
    Platform(TEXT("03 / approach"),FVector(9550,0,0),FVector(1100,1500,0),Pink);
    auto* E=Shot(TEXT("03 A / ACTION"),FVector(9960,0,230),FVector(300,500,310),FRotator::ZeroRotator,3,Pink);
    Platform(TEXT("03 / sky deck"),FVector(12000,0,1800),FVector(1500,1500,0),Pink);
    auto* F=Shot(TEXT("03 B / SKY"),FVector(11450,0,2040),FVector(100,500,200),FRotator::ZeroRotator,3,Pink);
    E->Destination=F; F->Destination=E;
    Arrow(FVector(12000,0,1808),Pink);
    Label(TEXT("03 / THE FINAL STUNT\nRUN. CUT. DROP. CUT."),FVector(9900,0,700),75,FColor(255,100,160));
    auto* G=Shot(TEXT("04 A / THE DROP"),FVector(13100,0,600),FVector(900,650,650),FRotator::ZeroRotator,3,Pink,true);
    auto* J=Shot(TEXT("04 B / THE WRAP"),FVector(14000,0,1000),FVector(100,550,220),FRotator(90,0,0),3,Pink);
    G->Destination=J; J->Destination=G;
    Platform(TEXT("FINALE / wrap stage"),FVector(15900,0,0),FVector(2500,2200,0),Gold);
    Arrow(FVector(14950,0,8),Pink);
    Label(TEXT("THAT'S A WRAP!"),FVector(16900,0,650),150,FColor(255,210,100));
    // Studio identity: dark soundstage, red curtains, illuminated gantries and scenic flats.
    Box(TEXT("Soundstage back wall"),FVector(7800,1900,1300),FVector(21000,100,6500),Dark);
    Box(TEXT("Backstage void floor"),FVector(7800,0,-2300),FVector(22000,12000,100),Dark);
    for(float X:{-1450.f,3200.f,7800.f,11500.f,17000.f})
    {
        Box(TEXT("Scenic backdrop"),FVector(X,1800,800),FVector(1700,55,2000),FLinearColor(.07f,.13f,.18f));
        for(float DX:{-850.f,850.f})
            for(int32 Fold=0;Fold<5;++Fold) Box(TEXT("Velvet curtain"),FVector(X+DX+Fold*40,1700,900),FVector(65,100,2100),FLinearColor(.25f+.025f*(Fold%2),.012f,.035f),false);
        Box(TEXT("Lighting gantry"),FVector(X,0,2900),FVector(40,3900,40),Cream,false);
        for(float Y:{-1400.f,1400.f})
        {
            Box(TEXT("Studio spotlight"),FVector(X,Y,2800),FVector(150,150,180),Gold,false,FRotator(25,0,0),TEXT("Cylinder"));
            auto* L=World->SpawnActor<APointLight>(FVector(X,Y*.65f,2300),FRotator::ZeroRotator); Tag(L,TEXT("Warm studio practical"));
            L->PointLightComponent->SetMobility(EComponentMobility::Movable);
            L->PointLightComponent->SetIntensity(1400000);
            L->PointLightComponent->SetAttenuationRadius(3800);
            L->PointLightComponent->SetLightColor(FLinearColor(1,.72f,.42f));
            L->PointLightComponent->SetCastShadows(false);
        }
    }
    auto* Sun=World->SpawnActor<ADirectionalLight>(FVector(0,0,3000),FRotator(-55,-35,0)); Tag(Sun,TEXT("Studio key light"));
    Sun->GetLightComponent()->SetMobility(EComponentMobility::Movable);
    Sun->GetLightComponent()->SetIntensity(3.5f);
    Sun->GetLightComponent()->SetLightColor(FLinearColor(.77f,.85f,1));
    auto* Sky=World->SpawnActor<ASkyLight>(); Tag(Sky,TEXT("Studio ambient fill"));
    Sky->GetLightComponent()->SetMobility(EComponentMobility::Movable);
    Sky->GetLightComponent()->SetIntensity(.8f);
    auto* Start=World->SpawnActor<APlayerStart>(FVector(-1100,0,180),FRotator::ZeroRotator); Tag(Start,TEXT("CUT TO / Player Start"));
    World->GetWorldSettings()->KillZ=-3000;
    UE_LOG(LogCutTo,Display,TEXT("Studio generated: 3 challenges, 8 reusable shots."));
}

ACutGameMode::ACutGameMode()
{
    DefaultPawnClass=ACutPerformer::StaticClass(); HUDClass=ACutHUD::StaticClass();
    PrimaryActorTick.bCanEverTick=true;
}
void ACutGameMode::BeginPlay()
{
    Super::BeginPlay();
    bSmoke=FParse::Param(FCommandLine::Get(),TEXT("CutToSmoke"));
}
void ACutGameMode::SmokeCheck(bool Result,const TCHAR* Message)
{
    UE_LOG(LogCutTo,Display,TEXT("SMOKE %s: %s"),Result?TEXT("PASS"):TEXT("FAIL"),Message);
    if(!Result) ++Failures;
}
void ACutGameMode::Tick(float Dt)
{
    Super::Tick(Dt);
    if(FParse::Param(FCommandLine::Get(),TEXT("CutToPreview")))
    {
        SmokeTime+=Dt;
        if(SmokeStep==0 && SmokeTime>5) { FScreenshotRequest::RequestScreenshot(TEXT("CutTo_Opening.png"),true,false); ++SmokeStep; }
        if(SmokeTime>7) FPlatformMisc::RequestExit(false);
        return;
    }
    if(!bSmoke) return;
    SmokeTime+=Dt;
    auto* P=Cast<ACutPerformer>(UGameplayStatics::GetPlayerCharacter(this,0));
    if(!P) { SmokeCheck(false,TEXT("Player spawned")); FPlatformMisc::RequestExitWithStatus(false,1); return; }
    if(SmokeStep==7 && P->GetActorLocation().X<4200) P->AddMovementInput(FVector::ForwardVector,1);
    if(SmokeStep==8 && P->CutCount==4)
    {
        P->AddMovementInput(FVector::ForwardVector,1);
        if(P->AvailableShot()) SmokeCheck(P->Cut(),TEXT("Real tower run and fall enters usable shot area"));
    }
    const float Wait=(SmokeStep==7?8.f:SmokeStep==8?4.f:(SmokeStep==2 || SmokeStep==4)?1.6f:.6f);
    if(SmokeTime<Wait) return;
    auto Find=[&](const TCHAR* Prefix)->ACutShot* { for(TActorIterator<ACutShot> It(GetWorld());It;++It) if(It->ShotName.StartsWith(Prefix)) return *It; return nullptr; };
    auto Prepare=[&](const TCHAR* Prefix,FVector Velocity,int32 Challenge)->ACutShot*
    {
        ACutShot* S=Find(Prefix);
        if(!S) { SmokeCheck(false,TEXT("Required shot exists")); return nullptr; }
        P->Restart(); P->CurrentChallenge=Challenge;
        P->SetActorLocation(S->GetActorLocation(),false,nullptr,ETeleportType::TeleportPhysics);
        P->GetCharacterMovement()->SetMovementMode(MOVE_Falling);
        P->GetCharacterMovement()->Velocity=Velocity;
        return S;
    };
    if(SmokeStep==0)
    {
        SmokeCheck(P->InputComponent!=nullptr,TEXT("Third-person performer input initialized"));
        if(auto* S=Prepare(TEXT("01 A"),FVector(800,0,300),1))
        {
            const float Before=P->GetVelocity().Size();
            SmokeCheck(P->Cut(),TEXT("Running airborne cut succeeds"));
            SmokeCheck(FMath::IsNearlyEqual(Before,P->GetVelocity().Size(),.1f),TEXT("Cut preserves speed magnitude"));
            SmokeCheck(P->GetActorLocation().Equals(S->Destination->Arrival->GetComponentLocation(),1),TEXT("Safe configured arrival used"));
            SmokeCheck(!P->Cut(),TEXT("Cooldown prevents immediate recut"));
        }
    }
    else if(SmokeStep==1)
    {
        SmokeCheck(P->GetActorLocation().X>1900,TEXT("Movement continues after first cut"));
        if(auto* S=Prepare(TEXT("02 A"),FVector(0,0,-1700),2))
        {
            SmokeCheck(P->Cut(),TEXT("Falling cut succeeds"));
            SmokeCheck(FMath::Abs(P->GetVelocity().X-1700)<.1f && FMath::Abs(P->GetVelocity().Z)<.1f,TEXT("Downward momentum rotates into positive X"));
            SmokeCheck(P->GetCharacterMovement()->IsFalling(),TEXT("Cut keeps airborne movement mode"));
            LaunchX=P->GetActorLocation().X;
        }
    }
    else if(SmokeStep==2)
    {
        SmokeCheck(P->GetActorLocation().X>LaunchX+700,TEXT("Physics retains horizontal launch speed"));
        SmokeCheck(P->GetCharacterMovement()->IsMovingOnGround() && P->GetActorLocation().X>7200 && P->GetActorLocation().X<9500,TEXT("Falling launch reaches broad landing platform"));
        if(Prepare(TEXT("03 A"),FVector(900,0,300),3)) SmokeCheck(P->Cut(),TEXT("Final stunt running cut"));
    }
    else if(SmokeStep==3)
    {
        if(Prepare(TEXT("04 A"),FVector(0,0,-1800),3)) SmokeCheck(P->Cut(),TEXT("Final stunt falling cut"));
    }
    else if(SmokeStep==4)
    {
        SmokeCheck(P->bFinished,TEXT("Final falling launch lands on wrap stage"));
        P->SetCheckpoint(3,FVector(8500,0,180)); P->Checkpoint=FVector(8500,0,180); P->Restart();
        SmokeCheck(P->GetActorLocation().Equals(P->Checkpoint,1),TEXT("Restart returns to checkpoint"));
        P->SetActorLocation(FVector(0,0,-2200));
    }
    else if(SmokeStep==5)
    {
        SmokeCheck(P->GetActorLocation().X>8000,TEXT("Void respawns performer"));
        P->SetActorLocation(FVector(15900,0,90)); P->GetCharacterMovement()->SetMovementMode(MOVE_Walking);
    }
    else if(SmokeStep==6)
    {
        SmokeCheck(P->bFinished,TEXT("Goal displays finish state"));
        P->CurrentChallenge=1; P->Restart(); P->SetActorLocation(FVector(1800,0,180));
    }
    else if(SmokeStep==7)
    {
        UE_LOG(LogCutTo,Display,TEXT("STAIR END location=%s challenge=%d grounded=%d"),*P->GetActorLocation().ToString(),P->CurrentChallenge,P->GetCharacterMovement()->IsMovingOnGround());
        SmokeCheck(P->CurrentChallenge==2 && P->GetActorLocation().Z>1700,TEXT("Character physically climbs staircase and arms tower checkpoint"));
        P->SetActorLocation(FVector(4450,0,1770));
        P->GetCharacterMovement()->StopMovementImmediately();
        P->CutCount=4;
    }
    else if(SmokeStep==8)
    {
        SmokeCheck(P->CutCount==5 && P->GetCharacterMovement()->IsMovingOnGround() && P->GetActorLocation().X>7200,TEXT("Real tower run, freefall and cut reaches landing"));
        UE_LOG(LogCutTo,Display,TEXT("CUTTO_SMOKE_COMPLETE failures=%d"),Failures);
        FPlatformMisc::RequestExitWithStatus(false,Failures?1:0);
    }
    ++SmokeStep; SmokeTime=0;
}

