"""Run via UnrealEditor-Cmd -ExecutePythonScript=<this file>. Creates only /Game/CutTo assets."""
import unreal

ROOT = '/Game/CutTo'
unreal.EditorAssetLibrary.make_directory(ROOT + '/Materials')
material_path = ROOT + '/Materials/M_Studio'
mat = unreal.load_asset(material_path)
if not mat:
    mat = unreal.AssetToolsHelpers.get_asset_tools().create_asset('M_Studio', ROOT + '/Materials', unreal.Material, unreal.MaterialFactoryNew())
    tint = unreal.MaterialEditingLibrary.create_material_expression(mat, unreal.MaterialExpressionVectorParameter, -400, 0)
    tint.set_editor_property('parameter_name', 'Tint')
    tint.set_editor_property('default_value', unreal.LinearColor(.2, .3, .4, 1))
    unreal.MaterialEditingLibrary.connect_material_property(tint, '', unreal.MaterialProperty.MP_BASE_COLOR)
    rough = unreal.MaterialEditingLibrary.create_material_expression(mat, unreal.MaterialExpressionConstant, -400, 200)
    rough.set_editor_property('r', .72)
    unreal.MaterialEditingLibrary.connect_material_property(rough, '', unreal.MaterialProperty.MP_ROUGHNESS)
    unreal.MaterialEditingLibrary.recompile_material(mat)
    unreal.EditorAssetLibrary.save_loaded_asset(mat)

palette = [(.24,.12,.055), (.028,.042,.065), (1,.55,.1), (.05,.7,.8), (.85,.12,.36), (.8,.73,.52), (.07,.13,.18), (.25,.012,.035), (.275,.012,.035)]
for r,g,b in palette:
    name = f'MI_R{int(r*1000+.5)}_G{int(g*1000+.5)}_B{int(b*1000+.5)}'
    instance = unreal.load_asset(ROOT + '/Materials/' + name)
    if not instance:
        instance = unreal.AssetToolsHelpers.get_asset_tools().create_asset(name, ROOT + '/Materials', unreal.MaterialInstanceConstant, unreal.MaterialInstanceConstantFactoryNew())
    unreal.MaterialEditingLibrary.set_material_instance_parent(instance, mat)
    unreal.MaterialEditingLibrary.set_material_instance_vector_parameter_value(instance, 'Tint', unreal.LinearColor(r,g,b,1))
    unreal.EditorAssetLibrary.save_loaded_asset(instance)

level_path = ROOT + '/LV_CutTo_Prototype'
levels = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
if unreal.EditorAssetLibrary.does_asset_exist(level_path):
    levels.load_level(level_path)
else:
    levels.new_level(level_path)
actors = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
studio_class = unreal.load_class(None, '/Script/DirectorsCutJAM.CutStudio')
studio = next((a for a in actors.get_all_level_actors() if a.get_class() == studio_class), None)
if studio is None:
    studio = actors.spawn_actor_from_class(studio_class, unreal.Vector(0, 0, 0))
studio.build_studio()
world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
world.get_world_settings().set_editor_property('default_game_mode', unreal.load_class(None, '/Script/DirectorsCutJAM.CutGameMode'))
unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).set_level_viewport_camera_info(unreal.Vector(-1800, -1800, 1300), unreal.Rotator(-18, 40, 0))
levels.save_current_level()
shots = [a for a in actors.get_all_level_actors() if a.get_class().get_name() == 'CutShot']
assert len(shots) == 8, f'Expected 8 shots, got {len(shots)}'
assert all(s.get_editor_property('destination') is not None for s in shots)
unreal.log('CUTTO_BUILD_COMPLETE: saved map with 8 connected shots')
