# CUT TO! Prototype

The live MCP repair is complete. See [the repair report](CUT_TO_REPAIR_REPORT.md) for the confirmed module-registration cause, preserved map data and successful live PIE keyboard tests. The `Modules` entry in the project descriptor must remain present so Unreal loads the gameplay classes.

Open `DirectorsCutJAM.uproject` in UE 5.8. Restart an editor session that was already running before the C++ module was added. The startup map is `/Game/CutTo/LV_CutTo_Prototype`. Press Play in **Selected Viewport** or **New Editor Window**, then click the viewport to capture the mouse.

Controls: WASD move, mouse look, Space jump, Left Shift sprint, E CUT, R restart the current challenge. Shift+F1 releases the mouse in PIE.

## Playing

1. Cyan / Missing Bridge: run toward the cyan frame, jump, and E. Land on the second deck. Follow the staircase to the gold tower.
2. Gold / Falling Shot: step or run off the far edge of the tower. Once inside the gold frame while falling, E turns downward speed into forward speed. Land on the wide gold deck to activate the third checkpoint.
3. Pink / Final Stunt: run and jump into 03 A, E to the sky deck. Cross it and fall from its far edge. E in 04 A launches toward the WRAP stage. Landing in the goal displays “THAT'S A WRAP!”

The game uses fixed destination positions. Move toward the far edge before cutting to carry more forward momentum. Holding sprint increases runway speed. Falling shots become available only while descending. The HUD displays availability, shot names, speed, controls, and challenge hints. Failed takes respawn at the current challenge; R replays the final challenge after finishing.

## Structure and editing

- `Source/DirectorsCutJAM/CutTo.h/.cpp`: performer, reusable shot actor, HUD, studio generator, game mode and runtime smoke checks.
- `/Game/CutTo/LV_CutTo_Prototype`: saved, editable geometry, eight linked shot actors, lighting, props and player start.
- `/Game/CutTo/Materials`: persistent studio material and color instances.
- Original first-person template content is preserved.

Select a `CutShot` actor to adjust its Destination, Challenge, falling requirement and name. Its ActivationArea box defines availability. Rotate its MomentumFrame component to change momentum transformation. Adjust the destination's SafeArrival component independently to place an upright character safely. Source and destination quaternions transform velocity as `DestinationFrame * SourceFrame.Inverse()`. Spawn positions are checked against blocking capsule collisions before teleport. Facing stays upright and the third-person camera keeps its horizon.

The studio's **Build Studio** button rebuilds actors tagged `CutToGenerated`; manual edits to those generated actors are replaced. Other actors are preserved. Challenge checkpoint and goal bounds currently live in the performer Tick function and must be updated if moving the course. The level generator uses world coordinates.

## Rebuild and checks

Close editor instances using the new module before rebuilding. From PowerShell in the project directory:

```powershell
.\Scripts\Build-CutTo.ps1
.\Scripts\Test-CutTo.ps1
```

Scripts accept `-EngineRoot` if UE is installed elsewhere. Build creates the C++ module and regenerates the saved map. Test runs actual CharacterMovement physics without rendering at a fixed 60 Hz, checks velocity preservation, rotated falling launches, landing platforms, restart, void recovery and finish state. It also drives the character up the staircase, off the tower and through a falling cut. The scenic staircase uses a smooth invisible collision ramp to avoid repeated step-up speed loss. Uncapped headless simulation can run at extreme frame rates and produce different traversal results; use the fixed-step test script. Logs are in `Saved/Logs`. These checks do not replace a human playthrough for timing, camera comfort or visual quality.

The CUT transition is a 0.16-second HUD edit flash; gameplay never pauses. No third-party assets are required. There is no custom edit audio in this prototype. The mannequin uses the existing unarmed animation blueprint.

## Validation performed

- UE 5.8.2 Development Editor C++ build succeeded.
- Unreal Python commandlet generated and saved the level, eight connected shots and ten material assets with zero errors and zero warnings on the final generation run.
- Runtime smoke suites passed at fixed 30, 60 and 120 Hz with `CUTTO_SMOKE_COMPLETE failures=0`. These cover preserved speed, downward-to-forward rotation, continued physics, both stunt landings, restart, void recovery, finish detection, physical staircase traversal/checkpoint activation and running off the tower into a successful cut and landing.
- A 1280×720 rendered opening view was captured and visually inspected. HUD text was enlarged and the opening sign moved out of the central route. The capture is `Saved/Screenshots/WindowsEditor/CutTo_Opening.png`.
- An uncapped headless run failed the staircase timing check; the repeatable suite uses fixed time steps. No full human playthrough or 3–5 minute pacing measurement was performed.
