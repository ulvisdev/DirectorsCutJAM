param([string]$EngineRoot = 'C:\Program Files\Epic Games\UE_5.8')
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$project = Join-Path $projectRoot 'DirectorsCutJAM.uproject'
& (Join-Path $EngineRoot 'Engine\Build\BatchFiles\Build.bat') DirectorsCutJAMEditor Win64 Development "-Project=$project" -WaitMutex -NoHotReloadFromIDE -NoLiveCoding
if ($LASTEXITCODE -ne 0) { throw 'C++ build failed.' }
& (Join-Path $EngineRoot 'Engine\Binaries\Win64\UnrealEditor-Cmd.exe') $project -run=pythonscript "-script=$PSScriptRoot\build_cut_to.py" -unattended -nullrhi -nosound
if ($LASTEXITCODE -ne 0) { throw 'Map generation failed.' }
