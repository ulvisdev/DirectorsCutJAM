"""Live PIE traversal test. Reuses the input probe without starting its first test."""
from pathlib import Path
import unreal
import json
import time

exec((Path(unreal.Paths.project_dir()) / 'Scripts/test_cut_to_pie_input.py').read_text().split('# Keep callback owner')[0])

class CutToCourseProbe(CutToInputProbe):
    def step(self, dt):
        now = time.monotonic()
        age = now-self.phase_time
        p = self.player.get_actor_location()
        v = self.player.get_velocity()
        self.samples.append(dict(t=now-self.started,phase=self.phase,x=p.x,y=p.y,z=p.z,vx=v.x,vz=v.z))
        if now-self.started>75 or (self.phase>0 and age>20):
            self.check('course phase timeout',False,phase=self.phase,x=p.x,z=p.z)
            self.finish()
            return
        if self.phase==0:
            self.player.restart()
            self.player.set_actor_location(unreal.Vector(1800,0,180),False,False)
            self.focus()
            self.key(0x57,True)
            self.next(1)
        elif self.phase==1 and p.x>4200:
            self.release()
            self.check('physical stair climb arms checkpoint two',self.player.get_editor_property('CurrentChallenge')==2 and p.z>1700,x=p.x,z=p.z)
            self.key(0x52,True)
            self.next(2)
        elif self.phase==2 and age>.2:
            self.release()
            self.check('R uses tower checkpoint',abs(p.x-4200)<5 and p.z>1700,x=p.x,z=p.z)
            self.player.set_actor_location(unreal.Vector(4400,0,1770),False,False)
            self.key(0x57,True)
            self.next(3)
        elif self.phase==3 and self.movement.is_falling() and p.z<1050:
            self.before_fall=[v.x,v.y,v.z]
            self.key(0x45,True)
            self.next(4)
        elif self.phase==4 and p.x>6000:
            self.release()
            self.check('E transforms real freefall into forward launch',v.x>900,
                       before=self.before_fall,after=[v.x,v.y,v.z],feedback=self.player.get_editor_property('Feedback'))
            self.next(5)
        elif self.phase==5 and not self.movement.is_falling():
            self.check('gold landing arms checkpoint three',p.x>7200 and self.player.get_editor_property('CurrentChallenge')==3,x=p.x,z=p.z)
            self.key(0x52,True)
            self.next(6)
        elif self.phase==6 and age>.2:
            self.release()
            self.check('R uses final challenge checkpoint',abs(p.x-8500)<5,x=p.x)
            self.key(0x57,True)
            self.next(7)
        elif self.phase==7 and p.x>9780:
            self.key(0x20,True)
            self.next(8)
        elif self.phase==8 and age>.12:
            self.key(0x45,True)
            self.next(9)
        elif self.phase==9 and p.x>11000:
            self.key(0x20,False)
            self.key(0x45,False)
            self.check('E reaches final sky deck',p.x<12750,feedback=self.player.get_editor_property('Feedback'))
            self.next(10)
        elif self.phase==10 and p.x>12750 and p.z<1200:
            self.key(0x45,True)
            self.next(11)
        elif self.phase==11 and p.x>14000:
            self.release()
            self.check('E launches final falling shot',v.x>900,feedback=self.player.get_editor_property('Feedback'))
            self.next(12)
        elif self.phase==12 and not self.movement.is_falling():
            self.check('wrap stage finishes course',p.x>15000 and self.player.get_editor_property('bFinished'),x=p.x,feedback=self.player.get_editor_property('Feedback'))
            self.key(0x52,True)
            self.next(13)
        elif self.phase==13 and age>.2:
            self.release()
            self.check('R replays final challenge after finish',abs(p.x-8500)<5 and not self.player.get_editor_property('bFinished'),x=p.x)
            self.finish()

    def finish(self):
        self.release()
        unreal.unregister_slate_post_tick_callback(self.handle)
        failures=sum(not r['passed'] for r in self.results)
        output=Path(unreal.Paths.project_saved_dir())/'Logs'/'CutToPIECourse.json'
        output.write_text(json.dumps(dict(results=self.results,failures=failures,samples=self.samples),indent=2))
        unreal.log('CUTTO_PIE_COURSE_COMPLETE failures='+str(failures))

cut_to_course_probe=CutToCourseProbe()
