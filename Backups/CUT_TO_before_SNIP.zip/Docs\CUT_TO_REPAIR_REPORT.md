# CUT TO! live MCP repair

## Confirmed cause

The active `DirectorsCutJAM.uproject` had no `Modules` array. The previously compiled `UnrealEditor-DirectorsCutJAM.dll` existed, but Unreal did not load the runtime module. Live MCP class discovery returned no `/Script/DirectorsCutJAM` classes. The editor log explicitly reported:

```
VerifyImport: Failed to find script package for import object 'Package /Script/DirectorsCutJAM'
CreateExport: Failed to load Outer for resource 'ActivationArea': CutShot ...
```

The level's GameMode reference resolved to None in that session. An MCP-started PIE session confirmed `GameModeBase` and `DefaultPawn_0`, instead of the custom gameplay classes. The level contained 390 loaded actors; the native shot actors and studio actor were absent.

The source files and saved shot data were intact. No recreation of the level or Blueprint conversion was needed.

## Repairs

1. Backed up the project descriptor and prototype map into `Saved/RepairBackup`.
2. Restored the `DirectorsCutJAM` **Runtime** module declaration with **Default** loading phase in the project descriptor, preserving `ModelContextProtocol` and `AllToolsets`.
3. Validated the module build, loaded the module into the live editor through MCP's console tools, and reloaded the existing level. All eight shot actors, all component references, the studio actor and the saved GameMode assignment recovered from disk.
4. Fixed an observed CharacterMovement warning during background editor throttling: a 0.016-second maximum physics step with eight iterations could not cover a 0.333-second frame. Raised the iteration limit to 32, retaining the small physics steps.
5. Recompiled, closed and reopened the editor, reconnected through MCP, and verified automatic class loading without a manual module command.

The map is byte-for-byte unchanged from the backup. SHA-256:

```
2D5E54DAFF8E35622D247244C85872593B324339229F5F9E010921CDB5C116DD
```

## Final live state

| Check | Result |
| --- | --- |
| Connected project | `DirectorsCutJAM - Unreal Editor`, verified through MCP |
| Open level | `/Game/CutTo/LV_CutTo_Prototype` |
| Native classes loaded automatically after restart | `CutGameMode`, `CutPerformer`, `CutHUD`, `CutShot`, `CutStudio` |
| GameMode override | `/Script/DirectorsCutJAM.CutGameMode` |
| Default pawn | `/Script/DirectorsCutJAM.CutPerformer` |
| HUD | `/Script/DirectorsCutJAM.CutHUD` |
| Possession | `PlayerController_0` possesses `CutPerformer_0` in PIE |
| Character assets | Manny simple mesh and existing `ABP_Unarmed` both loaded |
| Input component | `/Script/EnhancedInput.EnhancedInputComponent` |
| Shot actors | Eight, enabled, connected in four reciprocal pairs |
| Actor count outside PIE | 399, including the recovered eight shots and studio actor |

This implementation binds the configured **legacy actions and axes** using the inherited UInputComponent API. Enhanced Input's component processes these bindings. No `UInputAction` or input mapping context is required for this control path; the first-person template's IMC assets are unrelated to the custom character. Rewriting input was not necessary to fix the failure.

Live input settings were inspected and contained:

- `CutJump`: Space Bar; `CutSprint`: Left Shift; `CutEdit`: E; `CutRestart`: R.
- `CutForward`: W +1 / S -1; `CutRight`: D +1 / A -1.
- `CutLookX`: Mouse X +1; `CutLookY`: Mouse Y -1.

## Tests performed after the final compile and editor restart

`Scripts/test_cut_to_pie_input.py` and `Scripts/test_cut_to_pie_course.py` were launched through MCP's Slate console in the actual editor PIE world. Tick callbacks post Windows key-down/up messages to the Unreal window over multiple frames, so tests exercise the controller's real key bindings and CharacterMovement. They do not call `Cut()` to simulate an E press.

The first suite passed all checks:

- W moved the possessed performer; Space jumped; Shift reached 940 cm/s.
- E cut from 01 A to 01 B while airborne. Native CUT logs reported 956.396 cm/s before and after the teleport.
- The performer landed safely, CutHUD was attached, and R returned to the challenge start after the cut.

The course suite also passed:

- Physical stair climb activated checkpoint two, and R used the tower checkpoint.
- Running off the tower, freefalling, and pressing E rotated downward speed into forward velocity and reached the gold landing.
- Landing activated checkpoint three; R used its saved start.
- Running/jumping E reached the sky deck, and a second falling E reached the wrap stage.
- The goal set `bFinished` and the “THAT'S A WRAP!” message; R replayed the final challenge.

Both suites ended with `failures=0`. Evidence and sampled trajectories are in:

- `Saved/Logs/CutToPIEInput.json`
- `Saved/Logs/CutToPIECourse.json`
- `Saved/Logs/CutToRepairedEditor.log`

A fresh headless process also loaded the repaired project automatically and completed the 60 Hz smoke suite. See `Saved/Logs/CutToRepairColdStart.log` and `Saved/Logs/CutToRepairBuild.log`.

The live editor viewport was captured and inspected through MCP. It displayed the character, challenge name, controls, and `[ E ] CUT READY 01 A > 01 B` inside the first activation area.

## Output Log assessment and remaining human check

The clean editor launch no longer reports the missing gameplay script package or missing shot components. The completed PIE traversal no longer produces CharacterMovement iteration warnings. No gameplay exceptions or missing Blueprint references occurred during the completed tests.

The editor log retains initial toolset automation `Condition failed` entries, one MCP stale-session message during reconnection, and an early diagnostic-script Python accessor error that was corrected before the completed diagnostics. Those are separate from the gameplay systems; they are not presented as a clean zero-error editor log.

No human comfort/pacing test was performed. In the open level, press **Play**, click the viewport if input is not captured, and check mouse look, camera framing and camera comfort after a cut. W/Space/Shift/E/R and the course progression were tested automatically in PIE.

Do not use `BuildStudio()` or `Build-CutTo.ps1` just to launch the repaired level: those regenerate scenery. The existing map is already connected. Future plugin changes should preserve the project's runtime `Modules` entry.
