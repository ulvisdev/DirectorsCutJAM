"""Read-only live PIE diagnostics; run from Unreal's Python console via MCP."""
import unreal
import json

world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_game_world()
player = unreal.GameplayStatics.get_player_character(world, 0) if world else None
result = {'world': world.get_path_name() if world else None}
if player:
    controller = player.get_controller()
    movement = player.get_editor_property('character_movement')
    result.update(player_class=player.get_class().get_path_name(), player=player.get_path_name(),
                  controller=controller.get_path_name() if controller else None,
                  movement=movement.get_path_name(), location=str(player.get_actor_location()),
                  velocity=str(player.get_velocity()), challenge=player.get_editor_property('CurrentChallenge'),
                  mesh=player.mesh.skeletal_mesh_asset.get_path_name() if player.mesh.skeletal_mesh_asset else None,
                  anim=player.mesh.get_anim_instance().get_class().get_path_name() if player.mesh.get_anim_instance() else None,
                  hud=controller.get_hud().get_class().get_path_name() if controller and controller.get_hud() else None,
                  input_components=[c.get_class().get_path_name() for c in player.get_components_by_class(unreal.InputComponent)],
                  possessed_pawn=controller.get_controlled_pawn().get_path_name() if controller else None,
                  max_simulation_iterations=movement.get_editor_property('max_simulation_iterations'))
    actions = unreal.InputSettings.get_input_settings().get_editor_property('action_mappings')
    axes = unreal.InputSettings.get_input_settings().get_editor_property('axis_mappings')
    result['actions'] = [dict(action=str(a.action_name),key=str(unreal.InputLibrary.key_get_display_name(a.key))) for a in actions if str(a.action_name).startswith('Cut')]
    result['axes'] = [dict(axis=str(a.axis_name),key=str(unreal.InputLibrary.key_get_display_name(a.key)),scale=a.scale) for a in axes if str(a.axis_name).startswith('Cut')]
    result['legacy_scale'] = unreal.InputSettings.get_input_settings().get_editor_property('enable_legacy_input_scales')
    result['game_mode'] = unreal.GameplayStatics.get_game_mode(world).get_class().get_path_name()
unreal.log('CUTTO_LIVE_DIAGNOSTICS ' + json.dumps(result))
