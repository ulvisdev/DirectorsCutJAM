# Live Unreal MCP actor inventory

Historical inventory captured before the gameplay module repair. The module was unloaded in this snapshot. The repaired level has 399 loaded actors, including eight restored `CutShot` actors and `CutStudio_0`. See [the repair report](CUT_TO_REPAIR_REPORT.md).

Project confirmed by live editor window: `DirectorsCutJAM - Unreal Editor`.

Open level: `/Game/CutTo/LV_CutTo_Prototype`.

Actor count: **390**. Queried through Unreal MCP `SceneTools.find_actors` and `ActorTools.get_label`.

| Actor object name | Editor label |
| --- | --- |
| WorldSettings | WorldSettings |
| Brush_0 | Brush0 |
| StaticMeshActor_354 | 01 / rehearsal runway |
| StaticMeshActor_355 | 01 / rehearsal runway / apron |
| StaticMeshActor_356 | Illuminated stage edge |
| StaticMeshActor_357 | Scaffold upright |
| StaticMeshActor_358 | Scaffold upright |
| StaticMeshActor_359 | Illuminated stage edge |
| StaticMeshActor_360 | Scaffold upright |
| StaticMeshActor_361 | Scaffold upright |
| StaticMeshActor_362 | Deck seam |
| StaticMeshActor_363 | Deck seam |
| StaticMeshActor_364 | Deck seam |
| StaticMeshActor_365 | Deck seam |
| StaticMeshActor_366 | Deck seam |
| StaticMeshActor_367 | Deck seam |
| StaticMeshActor_368 | Deck seam |
| StaticMeshActor_369 | Deck seam |
| StaticMeshActor_370 | Deck seam |
| StaticMeshActor_371 | Deck seam |
| StaticMeshActor_372 | Deck seam |
| StaticMeshActor_373 | Deck seam |
| StaticMeshActor_374 | Deck seam |
| StaticMeshActor_375 | 01 / bridge landing |
| StaticMeshActor_376 | 01 / bridge landing / apron |
| StaticMeshActor_377 | Illuminated stage edge |
| StaticMeshActor_378 | Scaffold upright |
| StaticMeshActor_379 | Scaffold upright |
| StaticMeshActor_380 | Illuminated stage edge |
| StaticMeshActor_381 | Scaffold upright |
| StaticMeshActor_382 | Scaffold upright |
| StaticMeshActor_383 | Deck seam |
| StaticMeshActor_384 | Deck seam |
| StaticMeshActor_385 | Deck seam |
| StaticMeshActor_386 | Deck seam |
| StaticMeshActor_387 | Deck seam |
| StaticMeshActor_388 | Deck seam |
| StaticMeshActor_389 | Deck seam |
| StaticMeshActor_390 | Deck seam |
| StaticMeshActor_391 | Deck seam |
| StaticMeshActor_392 | Deck seam |
| StaticMeshActor_393 | Deck seam |
| StaticMeshActor_394 | Shot frame post |
| StaticMeshActor_395 | Shot frame post |
| StaticMeshActor_396 | Shot frame lintel |
| StaticMeshActor_397 | Shot frame lintel |
| StaticMeshActor_398 | Vintage camera body |
| StaticMeshActor_399 | Lens |
| StaticMeshActor_400 | Film reel |
| StaticMeshActor_401 | Film reel |
| StaticMeshActor_402 | Tripod |
| StaticMeshActor_403 | Tripod |
| StaticMeshActor_404 | Tripod third leg |
| Actor_15 | SIGN / 01 A |
| StaticMeshActor_405 | Shot frame post |
| StaticMeshActor_406 | Shot frame post |
| StaticMeshActor_407 | Shot frame lintel |
| StaticMeshActor_408 | Shot frame lintel |
| StaticMeshActor_409 | Vintage camera body |
| StaticMeshActor_410 | Lens |
| StaticMeshActor_411 | Film reel |
| StaticMeshActor_412 | Film reel |
| StaticMeshActor_413 | Tripod |
| StaticMeshActor_414 | Tripod |
| StaticMeshActor_415 | Tripod third leg |
| Actor_16 | SIGN / 01 B |
| StaticMeshActor_416 | Launch direction shaft |
| StaticMeshActor_417 | Launch direction head |
| StaticMeshActor_418 | Launch direction head |
| Actor_17 | SIGN / CUT TO! / ONE BUTTON. TWO SHOTS. / MOMENTUM NEVER STOPS. |
| Actor_18 | SIGN / 01 / THE MISSING BRIDGE / SPRINT + JUMP + E |
| Actor_19 | SIGN / NEXT SCENE  >  GOLD STAIRS |
| StaticMeshActor_419 | Tower staircase |
| StaticMeshActor_420 | Tower staircase |
| StaticMeshActor_421 | Tower staircase |
| StaticMeshActor_422 | Tower staircase |
| StaticMeshActor_423 | Tower staircase |
| StaticMeshActor_424 | Tower staircase |
| StaticMeshActor_425 | Tower staircase |
| StaticMeshActor_426 | Tower staircase |
| StaticMeshActor_427 | Tower staircase |
| StaticMeshActor_428 | Tower staircase |
| StaticMeshActor_429 | Tower staircase |
| StaticMeshActor_430 | Tower staircase |
| StaticMeshActor_431 | Tower staircase |
| StaticMeshActor_432 | Tower staircase |
| StaticMeshActor_433 | Tower staircase |
| StaticMeshActor_434 | Tower staircase |
| StaticMeshActor_435 | Tower staircase |
| StaticMeshActor_436 | Tower staircase |
| StaticMeshActor_437 | Tower staircase |
| StaticMeshActor_438 | Tower staircase |
| StaticMeshActor_439 | Tower staircase |
| StaticMeshActor_440 | Tower staircase |
| StaticMeshActor_441 | Tower staircase |
| StaticMeshActor_442 | Tower staircase |
| StaticMeshActor_443 | Tower staircase |
| StaticMeshActor_444 | Tower staircase |
| StaticMeshActor_445 | Tower staircase |
| StaticMeshActor_446 | Tower staircase |
| StaticMeshActor_447 | Tower staircase |
| StaticMeshActor_448 | Tower staircase |
| StaticMeshActor_449 | Tower staircase |
| StaticMeshActor_450 | Tower staircase |
| StaticMeshActor_451 | Tower staircase |
| StaticMeshActor_452 | Tower staircase |
| StaticMeshActor_453 | Tower staircase |
| StaticMeshActor_454 | Tower staircase |
| StaticMeshActor_455 | Tower staircase |
| StaticMeshActor_456 | Tower staircase |
| StaticMeshActor_457 | Tower staircase |
| StaticMeshActor_458 | Tower staircase |
| StaticMeshActor_459 | Tower staircase |
| StaticMeshActor_460 | Tower staircase |
| StaticMeshActor_461 | Tower staircase |
| StaticMeshActor_462 | Tower staircase |
| StaticMeshActor_463 | Tower staircase |
| StaticMeshActor_464 | Tower staircase |
| StaticMeshActor_465 | Tower staircase |
| StaticMeshActor_466 | Tower staircase |
| StaticMeshActor_467 | Staircase smooth collision |
| StaticMeshActor_468 | 02 / tower deck |
| StaticMeshActor_469 | 02 / tower deck / apron |
| StaticMeshActor_470 | Illuminated stage edge |
| StaticMeshActor_471 | Scaffold upright |
| StaticMeshActor_472 | Scaffold upright |
| StaticMeshActor_473 | Illuminated stage edge |
| StaticMeshActor_474 | Scaffold upright |
| StaticMeshActor_475 | Scaffold upright |
| StaticMeshActor_476 | Deck seam |
| StaticMeshActor_477 | Deck seam |
| StaticMeshActor_478 | Deck seam |
| StaticMeshActor_479 | Deck seam |
| StaticMeshActor_480 | Deck seam |
| StaticMeshActor_481 | Deck seam |
| Actor_20 | SIGN / 02 / THE FALLING SHOT / STEP OFF. FALL. CUT IN GOLD. |
| StaticMeshActor_482 | Shot frame post |
| StaticMeshActor_483 | Shot frame post |
| StaticMeshActor_484 | Shot frame lintel |
| StaticMeshActor_485 | Shot frame lintel |
| StaticMeshActor_486 | Vintage camera body |
| StaticMeshActor_487 | Lens |
| StaticMeshActor_488 | Film reel |
| StaticMeshActor_489 | Film reel |
| StaticMeshActor_490 | Tripod |
| StaticMeshActor_491 | Tripod |
| StaticMeshActor_492 | Tripod third leg |
| Actor_21 | SIGN / 02 A / DOWN |
| StaticMeshActor_493 | Shot frame post |
| StaticMeshActor_494 | Shot frame post |
| StaticMeshActor_495 | Shot frame lintel |
| StaticMeshActor_496 | Shot frame lintel |
| StaticMeshActor_497 | Vintage camera body |
| StaticMeshActor_498 | Lens |
| StaticMeshActor_499 | Film reel |
| StaticMeshActor_500 | Film reel |
| StaticMeshActor_501 | Tripod |
| StaticMeshActor_502 | Tripod |
| StaticMeshActor_503 | Tripod third leg |
| Actor_22 | SIGN / 02 B / FORWARD |
| StaticMeshActor_504 | 02 / broad stunt landing |
| StaticMeshActor_505 | 02 / broad stunt landing / apron |
| StaticMeshActor_506 | Illuminated stage edge |
| StaticMeshActor_507 | Scaffold upright |
| StaticMeshActor_508 | Scaffold upright |
| StaticMeshActor_509 | Illuminated stage edge |
| StaticMeshActor_510 | Scaffold upright |
| StaticMeshActor_511 | Scaffold upright |
| StaticMeshActor_512 | Deck seam |
| StaticMeshActor_513 | Deck seam |
| StaticMeshActor_514 | Deck seam |
| StaticMeshActor_515 | Deck seam |
| StaticMeshActor_516 | Deck seam |
| StaticMeshActor_517 | Deck seam |
| StaticMeshActor_518 | Deck seam |
| StaticMeshActor_519 | Deck seam |
| StaticMeshActor_520 | Deck seam |
| StaticMeshActor_521 | Deck seam |
| StaticMeshActor_522 | Deck seam |
| StaticMeshActor_523 | Deck seam |
| StaticMeshActor_524 | Deck seam |
| StaticMeshActor_525 | Deck seam |
| StaticMeshActor_526 | Deck seam |
| StaticMeshActor_527 | Launch direction shaft |
| StaticMeshActor_528 | Launch direction head |
| StaticMeshActor_529 | Launch direction head |
| Actor_23 | SIGN / DOWN  >  FORWARD / KEEP YOUR SPEED |
| StaticMeshActor_530 | 03 / approach |
| StaticMeshActor_531 | 03 / approach / apron |
| StaticMeshActor_532 | Illuminated stage edge |
| StaticMeshActor_533 | Scaffold upright |
| StaticMeshActor_534 | Scaffold upright |
| StaticMeshActor_535 | Illuminated stage edge |
| StaticMeshActor_536 | Scaffold upright |
| StaticMeshActor_537 | Scaffold upright |
| StaticMeshActor_538 | Deck seam |
| StaticMeshActor_539 | Deck seam |
| StaticMeshActor_540 | Deck seam |
| StaticMeshActor_541 | Deck seam |
| StaticMeshActor_542 | Deck seam |
| StaticMeshActor_543 | Deck seam |
| StaticMeshActor_544 | Deck seam |
| StaticMeshActor_545 | Shot frame post |
| StaticMeshActor_546 | Shot frame post |
| StaticMeshActor_547 | Shot frame lintel |
| StaticMeshActor_548 | Shot frame lintel |
| StaticMeshActor_549 | Vintage camera body |
| StaticMeshActor_550 | Lens |
| StaticMeshActor_551 | Film reel |
| StaticMeshActor_552 | Film reel |
| StaticMeshActor_553 | Tripod |
| StaticMeshActor_554 | Tripod |
| StaticMeshActor_555 | Tripod third leg |
| Actor_24 | SIGN / 03 A / ACTION |
| StaticMeshActor_556 | 03 / sky deck |
| StaticMeshActor_557 | 03 / sky deck / apron |
| StaticMeshActor_558 | Illuminated stage edge |
| StaticMeshActor_559 | Scaffold upright |
| StaticMeshActor_560 | Scaffold upright |
| StaticMeshActor_561 | Illuminated stage edge |
| StaticMeshActor_562 | Scaffold upright |
| StaticMeshActor_563 | Scaffold upright |
| StaticMeshActor_564 | Deck seam |
| StaticMeshActor_565 | Deck seam |
| StaticMeshActor_566 | Deck seam |
| StaticMeshActor_567 | Deck seam |
| StaticMeshActor_568 | Deck seam |
| StaticMeshActor_569 | Deck seam |
| StaticMeshActor_570 | Deck seam |
| StaticMeshActor_571 | Deck seam |
| StaticMeshActor_572 | Deck seam |
| StaticMeshActor_573 | Deck seam |
| StaticMeshActor_574 | Shot frame post |
| StaticMeshActor_575 | Shot frame post |
| StaticMeshActor_576 | Shot frame lintel |
| StaticMeshActor_577 | Shot frame lintel |
| StaticMeshActor_578 | Vintage camera body |
| StaticMeshActor_579 | Lens |
| StaticMeshActor_580 | Film reel |
| StaticMeshActor_581 | Film reel |
| StaticMeshActor_582 | Tripod |
| StaticMeshActor_583 | Tripod |
| StaticMeshActor_584 | Tripod third leg |
| Actor_25 | SIGN / 03 B / SKY |
| StaticMeshActor_585 | Launch direction shaft |
| StaticMeshActor_586 | Launch direction head |
| StaticMeshActor_587 | Launch direction head |
| Actor_26 | SIGN / 03 / THE FINAL STUNT / RUN. CUT. DROP. CUT. |
| StaticMeshActor_588 | Shot frame post |
| StaticMeshActor_589 | Shot frame post |
| StaticMeshActor_590 | Shot frame lintel |
| StaticMeshActor_591 | Shot frame lintel |
| StaticMeshActor_592 | Vintage camera body |
| StaticMeshActor_593 | Lens |
| StaticMeshActor_594 | Film reel |
| StaticMeshActor_595 | Film reel |
| StaticMeshActor_596 | Tripod |
| StaticMeshActor_597 | Tripod |
| StaticMeshActor_598 | Tripod third leg |
| Actor_27 | SIGN / 04 A / THE DROP |
| StaticMeshActor_599 | Shot frame post |
| StaticMeshActor_600 | Shot frame post |
| StaticMeshActor_601 | Shot frame lintel |
| StaticMeshActor_602 | Shot frame lintel |
| StaticMeshActor_603 | Vintage camera body |
| StaticMeshActor_604 | Lens |
| StaticMeshActor_605 | Film reel |
| StaticMeshActor_606 | Film reel |
| StaticMeshActor_607 | Tripod |
| StaticMeshActor_608 | Tripod |
| StaticMeshActor_609 | Tripod third leg |
| Actor_28 | SIGN / 04 B / THE WRAP |
| StaticMeshActor_610 | FINALE / wrap stage |
| StaticMeshActor_611 | FINALE / wrap stage / apron |
| StaticMeshActor_612 | Illuminated stage edge |
| StaticMeshActor_613 | Scaffold upright |
| StaticMeshActor_614 | Scaffold upright |
| StaticMeshActor_615 | Illuminated stage edge |
| StaticMeshActor_616 | Scaffold upright |
| StaticMeshActor_617 | Scaffold upright |
| StaticMeshActor_618 | Deck seam |
| StaticMeshActor_619 | Deck seam |
| StaticMeshActor_620 | Deck seam |
| StaticMeshActor_621 | Deck seam |
| StaticMeshActor_622 | Deck seam |
| StaticMeshActor_623 | Deck seam |
| StaticMeshActor_624 | Deck seam |
| StaticMeshActor_625 | Deck seam |
| StaticMeshActor_626 | Deck seam |
| StaticMeshActor_627 | Deck seam |
| StaticMeshActor_628 | Deck seam |
| StaticMeshActor_629 | Deck seam |
| StaticMeshActor_630 | Deck seam |
| StaticMeshActor_631 | Deck seam |
| StaticMeshActor_632 | Deck seam |
| StaticMeshActor_633 | Deck seam |
| StaticMeshActor_634 | Launch direction shaft |
| StaticMeshActor_635 | Launch direction head |
| StaticMeshActor_636 | Launch direction head |
| Actor_29 | SIGN / THAT'S A WRAP! |
| StaticMeshActor_637 | Soundstage back wall |
| StaticMeshActor_638 | Backstage void floor |
| StaticMeshActor_639 | Scenic backdrop |
| StaticMeshActor_640 | Velvet curtain |
| StaticMeshActor_641 | Velvet curtain |
| StaticMeshActor_642 | Velvet curtain |
| StaticMeshActor_643 | Velvet curtain |
| StaticMeshActor_644 | Velvet curtain |
| StaticMeshActor_645 | Velvet curtain |
| StaticMeshActor_646 | Velvet curtain |
| StaticMeshActor_647 | Velvet curtain |
| StaticMeshActor_648 | Velvet curtain |
| StaticMeshActor_649 | Velvet curtain |
| StaticMeshActor_650 | Lighting gantry |
| StaticMeshActor_651 | Studio spotlight |
| PointLight_10 | Warm studio practical |
| StaticMeshActor_652 | Studio spotlight |
| PointLight_11 | Warm studio practical |
| StaticMeshActor_653 | Scenic backdrop |
| StaticMeshActor_654 | Velvet curtain |
| StaticMeshActor_655 | Velvet curtain |
| StaticMeshActor_656 | Velvet curtain |
| StaticMeshActor_657 | Velvet curtain |
| StaticMeshActor_658 | Velvet curtain |
| StaticMeshActor_659 | Velvet curtain |
| StaticMeshActor_660 | Velvet curtain |
| StaticMeshActor_661 | Velvet curtain |
| StaticMeshActor_662 | Velvet curtain |
| StaticMeshActor_663 | Velvet curtain |
| StaticMeshActor_664 | Lighting gantry |
| StaticMeshActor_665 | Studio spotlight |
| PointLight_12 | Warm studio practical |
| StaticMeshActor_666 | Studio spotlight |
| PointLight_13 | Warm studio practical |
| StaticMeshActor_667 | Scenic backdrop |
| StaticMeshActor_668 | Velvet curtain |
| StaticMeshActor_669 | Velvet curtain |
| StaticMeshActor_670 | Velvet curtain |
| StaticMeshActor_671 | Velvet curtain |
| StaticMeshActor_672 | Velvet curtain |
| StaticMeshActor_673 | Velvet curtain |
| StaticMeshActor_674 | Velvet curtain |
| StaticMeshActor_675 | Velvet curtain |
| StaticMeshActor_676 | Velvet curtain |
| StaticMeshActor_677 | Velvet curtain |
| StaticMeshActor_678 | Lighting gantry |
| StaticMeshActor_679 | Studio spotlight |
| PointLight_14 | Warm studio practical |
| StaticMeshActor_680 | Studio spotlight |
| PointLight_15 | Warm studio practical |
| StaticMeshActor_681 | Scenic backdrop |
| StaticMeshActor_682 | Velvet curtain |
| StaticMeshActor_683 | Velvet curtain |
| StaticMeshActor_684 | Velvet curtain |
| StaticMeshActor_685 | Velvet curtain |
| StaticMeshActor_686 | Velvet curtain |
| StaticMeshActor_687 | Velvet curtain |
| StaticMeshActor_688 | Velvet curtain |
| StaticMeshActor_689 | Velvet curtain |
| StaticMeshActor_690 | Velvet curtain |
| StaticMeshActor_691 | Velvet curtain |
| StaticMeshActor_692 | Lighting gantry |
| StaticMeshActor_693 | Studio spotlight |
| PointLight_16 | Warm studio practical |
| StaticMeshActor_694 | Studio spotlight |
| PointLight_17 | Warm studio practical |
| StaticMeshActor_695 | Scenic backdrop |
| StaticMeshActor_696 | Velvet curtain |
| StaticMeshActor_697 | Velvet curtain |
| StaticMeshActor_698 | Velvet curtain |
| StaticMeshActor_699 | Velvet curtain |
| StaticMeshActor_700 | Velvet curtain |
| StaticMeshActor_701 | Velvet curtain |
| StaticMeshActor_702 | Velvet curtain |
| StaticMeshActor_703 | Velvet curtain |
| StaticMeshActor_704 | Velvet curtain |
| StaticMeshActor_705 | Velvet curtain |
| StaticMeshActor_706 | Lighting gantry |
| StaticMeshActor_707 | Studio spotlight |
| PointLight_18 | Warm studio practical |
| StaticMeshActor_708 | Studio spotlight |
| PointLight_19 | Warm studio practical |
| DirectionalLight_1 | Studio key light |
| SkyLight_1 | Studio ambient fill |
| PlayerStart_1 | CUT TO / Player Start |
| BuoyancyManager_0 | BuoyancyManager0 |
| DefaultPhysicsVolume_0 | DefaultPhysicsVolume0 |
| GameplayDebuggerPlayerManager_0 | GameplayDebuggerPlayerManager0 |
| ChaosDebugDrawActor | Actor |
| AbstractNavData-Default | AbstractNavData-Default |

