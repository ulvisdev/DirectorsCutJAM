param([string]$EngineRoot = 'C:\Program Files\Epic Games\UE_5.8')
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$editor = Join-Path $EngineRoot 'Engine\Binaries\Win64\UnrealEditor-Cmd.exe'
$project = Join-Path $projectRoot 'DirectorsCutJAM.uproject'
$log = Join-Path $projectRoot 'Saved\Logs\CutToSmoke.log'
& $editor $project /Game/CutTo/LV_CutTo_Prototype -game -CutToSmoke -unattended -nullrhi -nosound -nosplash -NoLoadingScreen -UseFixedTimeStep -FPS=60 "-abslog=$log"
if ($LASTEXITCODE -ne 0) { throw "CUT TO smoke test failed. See $log" }
$report = Get-Content -LiteralPath $log
$report | Select-String 'SMOKE|CUTTO_SMOKE_COMPLETE'
if (-not ($report | Select-String 'CUTTO_SMOKE_COMPLETE failures=0')) { throw 'Smoke test did not complete successfully.' }
