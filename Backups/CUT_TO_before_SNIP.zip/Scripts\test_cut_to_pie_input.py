"""Exercise actual Windows key input in the current PIE world, started via MCP.

Uses an editor tick callback so Unreal keeps processing input/physics between
key-down and key-up. Does not alter or save the editor level.
"""
import unreal
import ctypes
import json
import time
from pathlib import Path

class CutToInputProbe:
    def __init__(self):
        self.world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_game_world()
        self.player = unreal.GameplayStatics.get_player_character(self.world, 0)
        self.pc = self.player.get_controller()
        self.movement = self.player.get_editor_property('character_movement')
        self.started = time.monotonic()
        self.phase = 0
        self.phase_time = 0
        self.keys = set()
        ctypes.windll.user32.FindWindowW.restype = ctypes.c_void_p
        self.hwnd = ctypes.windll.user32.FindWindowW(None, 'DirectorsCutJAM - Unreal Editor')
        if not self.hwnd:
            raise RuntimeError('Unreal Editor window was not found')
        self.results = []
        self.samples = []
        self.max_jump_z = 0
        self.handle = unreal.register_slate_post_tick_callback(self.tick)
        unreal.log('CUTTO_PIE_INPUT_BEGIN')

    def key(self, vk, down):
        if down:
            self.keys.add(vk)
        else:
            self.keys.discard(vk)
        scan = ctypes.windll.user32.MapVirtualKeyW(vk, 0)
        flags = 1 | (scan << 16) | (0 if down else 0xC0000000)
        ctypes.windll.user32.PostMessageW(ctypes.c_void_p(self.hwnd), 0x100 if down else 0x101, vk, flags)

    def release(self):
        for vk in list(self.keys):
            self.key(vk, False)

    def check(self, name, condition, **data):
        row = dict(name=name, passed=bool(condition), **data)
        self.results.append(row)
        unreal.log('CUTTO_PIE_INPUT ' + json.dumps(row))

    def next(self, phase):
        self.phase = phase
        self.phase_time = time.monotonic()

    def focus(self):
        unreal.WidgetLibrary.set_input_mode_game_only(self.pc)
        unreal.WidgetLibrary.set_focus_to_game_viewport()
        self.pc.set_editor_property('show_mouse_cursor', False)

    def tick(self, dt):
        try:
            self.step(dt)
        except Exception as error:
            self.release()
            unreal.unregister_slate_post_tick_callback(self.handle)
            unreal.log_error('CUTTO_PIE_INPUT_EXCEPTION ' + str(error))

    def step(self, dt):
        now = time.monotonic()
        age = now - self.phase_time
        p = self.player.get_actor_location()
        v = self.player.get_velocity()
        self.samples.append(dict(t=now-self.started, phase=self.phase, x=p.x, y=p.y, z=p.z,
                                 vx=v.x, vy=v.y, vz=v.z))
        if now-self.started > 25:
            self.check('probe timeout', False, phase=self.phase)
            self.finish()
            return
        if self.phase == 0:
            self.player.restart()
            self.focus()
            self.next(1)
        elif self.phase == 1 and age > .6:
            self.start_x = p.x
            self.start_z = p.z
            self.key(0x57, True)  # W
            self.next(2)
        elif self.phase == 2 and age > .8:
            self.check('W moves possessed performer', p.x > self.start_x+200,
                       distance=p.x-self.start_x)
            self.release()
            self.key(0x20, True)  # Space
            self.max_jump_z = p.z
            self.next(3)
        elif self.phase == 3:
            self.max_jump_z = max(self.max_jump_z, p.z)
            if age > .25:
                self.release()
            if age > .8:
                self.check('Space jumps', self.max_jump_z > self.start_z+80,
                           rise=self.max_jump_z-self.start_z)
                self.key(0x52, True)  # R
                self.next(4)
        elif self.phase == 4 and age > .15:
            self.release()
            self.check('R restarts challenge one', abs(p.x+1100)<5, x=p.x)
            self.player.set_actor_location(unreal.Vector(-300, 0, 100), False, False)
            self.focus()
            self.key(0x57, True)
            self.key(0xA0, True)  # Left Shift
            self.next(5)
        elif self.phase == 5:
            if p.x > 100:
                self.check('Shift increases run speed', v.x > 700, vx=v.x)
                self.key(0x20, True)
                self.next(6)
            elif age > 3:
                self.check('run enters source shot', False, x=p.x)
                self.finish()
        elif self.phase == 6 and age > .12:
            self.check('performer airborne in first source', v.z > 100 and p.x<700, x=p.x, vz=v.z)
            self.before_cut = [v.x,v.y,v.z]
            self.key(0x45, True)  # E, through the real key binding
            self.next(7)
        elif self.phase == 7 and age > .12:
            self.release()
            self.check('E triggers first momentum cut', p.x > 1800,
                       x=p.x, feedback=self.player.get_editor_property('Feedback'),
                       velocity_before=self.before_cut, velocity_after=[v.x,v.y,v.z])
            self.next(8)
        elif self.phase == 8 and age > 1:
            self.check('first cut reaches landing', p.x>1800 and not self.movement.is_falling(),
                       x=p.x,z=p.z,grounded=not self.movement.is_falling())
            self.key(0x52, True)
            self.next(9)
        elif self.phase == 9 and age > .15:
            self.release()
            self.check('R works after cut', abs(p.x+1100)<5,x=p.x)
            self.check('HUD attached', self.pc.get_hud().get_class().get_name()=='CutHUD')
            self.finish()

    def finish(self):
        self.release()
        unreal.unregister_slate_post_tick_callback(self.handle)
        failures = sum(not r['passed'] for r in self.results)
        output = Path(unreal.Paths.project_saved_dir()) / 'Logs' / 'CutToPIEInput.json'
        output.write_text(json.dumps(dict(results=self.results, failures=failures, samples=self.samples),indent=2))
        unreal.log('CUTTO_PIE_INPUT_COMPLETE failures=' + str(failures))

# Keep callback owner alive for the asynchronous run.
cut_to_input_probe = CutToInputProbe()
